#include"stdafx.h"
#include "resource.h"

#define MAX_LOADSTRING 100

// ȫ�ֱ���:
HINSTANCE hInst;								// ��ǰʵ��
TCHAR szTitle[MAX_LOADSTRING];					// �������ı�
TCHAR szWindowClass[MAX_LOADSTRING];

LRESULT CALLBACK  WndProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam);

int APIENTRY _tWinMain(HINSTANCE hInstance,HINSTANCE hprevInstance,LPTSTR lpCmdLine,int nCmdShow)
{

	MSG msg;
	
	//���ַ������м����ַ���
	LoadString(hInstance,IDS_APP_TITLE,szTitle,MAX_LOADSTRING);
	LoadString(hInstance, IDC_LESSION6CREATEWIN,szWindowClass,MAX_LOADSTRING);
   //1.��ƴ�����
	WNDCLASS wcex;

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_LESSION6CREATEWIN));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_LESSION6CREATEWIN);
	wcex.lpszClassName	= _T("MyWin");


    //2.ע�ᴰ����
	RegisterClass(&wcex);
    
	//3.��������
	HWND hwnd;
	hwnd = CreateWindow(
					_T("MyWin"),
					_T("Lession6"),
					WS_OVERLAPPEDWINDOW,
                    CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
					CW_USEDEFAULT,
                    NULL,
					NULL,
					hInstance,
					NULL);
 if (!hwnd)
   {
      MessageBox(NULL,_T("��������ʧ��"),_T("����"),MB_OK);
   }
	 //4.��ʾ����
	ShowWindow(hwnd, nCmdShow);
	//5.���´���
	UpdateWindow(hwnd);

   //6.ѧϰѭ��
  while(GetMessage(&msg,NULL,0,0))
  {
      TranslateMessage(&msg);
	  DispatchMessage(&msg);
  }


	 return (int) msg.wParam;
	
}

LRESULT CALLBACK  WndProc(HWND hwnd,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

    switch(uMsg)
	{
	case WM_COMMAND:
		wmId = LOWORD(wParam);
		switch(wmId)
		{
		case IDM_EXIT:
			PostQuitMessage(0);
			break;
		case IDM_ABOUT:
			MessageBox(NULL,_T("Lession6-create-win\n version 1.0\n Date Created: 2024/08/29"),_T("About"),0);
			break;
			default:
			return DefWindowProc(hwnd, uMsg, wParam, lParam);
		}
		break;
	case WM_PAINT:
		hdc = BeginPaint(hwnd,&ps);
		 TextOut(hdc,0,0,_T("Hello, Windows"),wcslen(_T("Hello, Windows")));
		EndPaint(hwnd,&ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}

   return 0;
}