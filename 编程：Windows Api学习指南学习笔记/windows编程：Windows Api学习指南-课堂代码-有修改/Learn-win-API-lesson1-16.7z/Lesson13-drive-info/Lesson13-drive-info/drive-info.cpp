#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>
#define BUFSIZE 1024

BOOL DisplayDriveInfo(LPSTR szDrive)
{
    UINT uDriverType;
    DWORD dwVolumeSerialNumber;
    DWORD dwMaximumComponentlength;
    DWORD dwFileSystemFlags;
    CHAR szFileSystemNameBuffer[BUFSIZE];
    CHAR szDriveName[MAX_PATH]; 
	//��ʾ�̷�
	printf("\n%s\n",szDrive);
	//1.�жϴ�������
	uDriverType=GetDriveType(szDrive);
	switch(uDriverType)
	{
	case DRIVE_UNKNOWN:
		printf("Unknown drive.\n");
		break;
    case DRIVE_NO_ROOT_DIR:
		printf("The root directory does not exist.\n");
		break;
    case DRIVE_REMOVABLE:
		printf("Removable Disk Drive.\n");
		break;
    case DRIVE_FIXED:
		printf("Hard Drive.\n");
		break;
     case DRIVE_REMOTE:
		 printf("Remote Drive.\n");
		break;
    case DRIVE_CDROM:
		printf("CDRom drive.\n");
		break;
    case DRIVE_RAMDISK:
		printf("Ram Disk Drive\n");
		break;
	}
    //2.��ȡ�߼�����������Ϣ
   if(!GetVolumeInformation(
	      szDrive,
		  szDriveName,
		  MAX_PATH,
		  &dwVolumeSerialNumber,
		  &dwMaximumComponentlength,
		  &dwFileSystemFlags,
		  szFileSystemNameBuffer,
		  BUFSIZ))
   {
      return FALSE;
   }
   //3.��ʾ��Ϣ
   if(0!=lstrlen(szDriveName))
   {
      printf("\nDrive Name is %s.\n",szDriveName);
   }
    printf("\nVolume Serial is %u.",dwVolumeSerialNumber );
    printf("\nMaximum Component Length is %u.",dwMaximumComponentlength);
    printf("\nSystem Type is %s.\n",szFileSystemNameBuffer);
	  if (dwFileSystemFlags & FILE_VOLUME_QUOTAS)
    {

        printf("The file system supports disk Quotas.\n");
    }

    if (dwFileSystemFlags & FILE_SUPPORTS_REPARSE_POINTS)
    {
        printf("The file system does not support volume mount points.\n");

    }

    if (dwFileSystemFlags & FILE_CASE_SENSITIVE_SEARCH)
    {
        printf("The file system supports case-sentitive file name.\n");
    }

    printf("...\n");
	return TRUE;
}
int main()
{
  CHAR  szLogicalStr[BUFSIZE];
  PCHAR  szDrive;
  ZeroMemory(szLogicalStr,BUFSIZE);
  GetLogicalDriveStrings(BUFSIZE-1,szLogicalStr);
  szDrive = (PCHAR)szLogicalStr;
  do
  {
    if(!DisplayDriveInfo(szDrive))
	{
	   printf("Get Drive Info Failed...");
	}
	szDrive +=(lstrlen(szDrive)+1);
  } while(lstrlen(szDrive)!='\x00');
  system("pause");
  return 0;
}