#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>
#define BUFSIZE 1024

BOOL testGetDiskFreeSpace(LPSTR szDrive);
BOOL testGetDiskFreeSpaceEx(LPSTR szDrive);


int main()
{
  CHAR  szLogicalStr[BUFSIZE];
  PCHAR  szDrive;
  ZeroMemory(szLogicalStr,BUFSIZE);
  GetLogicalDriveStrings(BUFSIZE-1,szLogicalStr);
  szDrive = (PCHAR)szLogicalStr;
  do
  {
	  printf("Drive: %s\n",szDrive);
  /*  if(!testGetDiskFreeSpace(szDrive))
	{
		printf("test Failed...\n");
		return 1;
	}*/
	  if(!testGetDiskFreeSpaceEx(szDrive))
	{
		printf("test Failed...\n");
		return 1;
	}
	szDrive +=(lstrlen(szDrive)+1);
	printf("===========\n");
  } while(lstrlen(szDrive)!='\x00');
  system("pause");
  return 0;
}

BOOL testGetDiskFreeSpace(LPSTR szDrive)
{
     DWORD  dwSectorsPerCluster;             // pointer to sectors per cluster
     DWORD dwBytesPerSector;                  // pointer to bytes per sector
     DWORD dwNumberOfFreeClusters;   // pointer to number of free clusters
     DWORD dwTotalNumberOfClusters;  // pointer to total number of clusters
     BOOL  bRet;
	 bRet = GetDiskFreeSpace(szDrive,&dwSectorsPerCluster,&dwBytesPerSector,
		          &dwNumberOfFreeClusters,&dwTotalNumberOfClusters);
	 if(!bRet)
	 {
		 printf("Get Disk Space Failed...");
	 }
	 printf("Basic Infos:\n");
	 printf("Sectors Per Cluster: %d\n",dwSectorsPerCluster);
	 printf("Bytes Per Sector: %d\n",dwBytesPerSector);
	 printf("Number Of Free Clusters: %d\n",dwNumberOfFreeClusters);
	 printf("Total Number Of Clusters: %d\n",dwTotalNumberOfClusters);
	 printf("Extented Infos:\n");
   return  bRet;
}

/**
  PULARGE_INTEGER��ָ��һ���������ṹ����� ���������ָ�룬
  ���ULARGE_INTEGER��QuadPart���Բ�������
*/
BOOL testGetDiskFreeSpaceEx(LPSTR szDrive)
{
	ULARGE_INTEGER  uFreeBytesAvailableToCaller; // receives the number of bytes ondisk available to the caller
    ULARGE_INTEGER  uTotalNumberOfBytes;    // receives the number of bytes on disk
    ULARGE_INTEGER  uTotalNumberOfFreeBytes; // receives the free bytes on disk
    BOOL bRet;
    bRet = GetDiskFreeSpaceEx(szDrive,&uFreeBytesAvailableToCaller,
		         &uTotalNumberOfBytes,&uTotalNumberOfFreeBytes);
	if(!bRet)
	{
	  printf("Get Disk Space Failed...");
	}
	printf(" Free Bytes Available To Caller: %dGB\n", uFreeBytesAvailableToCaller.QuadPart/1024/1024/1024);
	printf(" Total Number Of Bytes : %dGB\n", uTotalNumberOfBytes.QuadPart/1024/1024/1024);
	printf(" Total Number Of FreeBytes: %dGB\n", uTotalNumberOfFreeBytes.QuadPart/1024/1024/1024);

   return  bRet;
}