#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

int main()
{
	HANDLE hVol;
    CHAR szVolume[MAX_PATH] = { 0 };
	hVol = FindFirstVolumeA(szVolume,MAX_PATH);
	BOOL bFlag;
   if(hVol == INVALID_HANDLE_VALUE)
   {
	   MessageBox(NULL,"Find First Volume Failed...","error",0);
   }
   printf("First Volume:%s\n",szVolume);
   while(FindNextVolume(hVol,szVolume,MAX_PATH))
   {
        printf("NextVolume:%s\n",szVolume);
   }
   bFlag = FindVolumeClose(hVol);
	system("pause");
	return bFlag;
}