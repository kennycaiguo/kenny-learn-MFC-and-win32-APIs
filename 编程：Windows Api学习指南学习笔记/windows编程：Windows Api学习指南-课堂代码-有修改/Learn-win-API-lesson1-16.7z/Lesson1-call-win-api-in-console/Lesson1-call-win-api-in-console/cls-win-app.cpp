#include<iostream>
#include<Windows.h>

using namespace std;

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE prev,LPSTR lpCmdLine,int nCmdShow)
{
	/*printf("Hello,Windows!!!");*/
	cout << "Call Window API from console" << endl;
	MessageBox(NULL, TEXT("Hello,windows!!!"), TEXT("info"),MB_OK);
	system("pause");
	return 0;
}
