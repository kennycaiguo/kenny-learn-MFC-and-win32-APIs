#include<Windows.h>
#include"resource.h"

//�Ի���ص�����
INT_PTR CALLBACK Dlgproc(
  HWND hwnd,
  UINT uMsg,
  WPARAM wParam,
  LPARAM lParam
);

HBITMAP bitmap1,bitmap2,com_bit,bitOld1,bitOld2;
HINSTANCE hinDlg;

int APIENTRY WinMain(HINSTANCE hinstance,HINSTANCE prev,LPSTR lpCmdLine,int nCmdShow)
{
	 hinDlg = hinstance;
	 DialogBox(hinstance,MAKEINTRESOURCE(IDD_MAIN),NULL,(DLGPROC)Dlgproc);
     return 0;
}

INT_PTR CALLBACK Dlgproc(
  HWND hDlg,
  UINT uMsg,
  WPARAM wParam,
  LPARAM lParam
)
{
	HWND hwndPic;
	HDC memDC,hdcPic;
	HBITMAP bitmap1,bitmap2;
	BITMAP bm;
	BOOL ret = TRUE;
	hwndPic = GetDlgItem(hDlg,IDC_PIC);
    RECT rc;
    HBRUSH hBrush;


	int wmId = LOWORD(wParam);
	switch(uMsg)
	{
	case WM_COMMAND:
            switch(wmId)
		   {
		   case IDC_BUTTON1:
			   //MessageBox(hDlg,"Button1 Clicked","info",0);
			   	hdcPic = GetDC(hwndPic);
	            memDC = CreateCompatibleDC(hdcPic);
					/*
				  �Ȱ�ԭ����ͼƬ����
					*/
				 hBrush = CreateSolidBrush(RGB(255,255,255));
                GetClientRect(hwndPic,&rc);
                FillRect(hdcPic,&rc,hBrush);
               bitmap1 = LoadBitmap(hinDlg,MAKEINTRESOURCE(IDB_BITMAP1));
			   if(!bitmap1)
			   {
                     MessageBox(hDlg,"Load Bitmap Failed","error",0);
			   }
               GetObject(bitmap1,sizeof(bm),&bm);
                SelectObject(memDC,bitmap1);
                GetClientRect(hwndPic,&rc);
				//BitBlt(hdcPic,rc.left,rc.top,bm.bmWidth,bm.bmHeight,memDC,0,0,SRCCOPY);
				//BitBlt(hdcPic,rc.left,rc.top,rc.right,rc.bottom,memDC,0,0,SRCCOPY);
				StretchBlt(hdcPic,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top,memDC,0,0,bm.bmWidth,bm.bmHeight ,SRCCOPY);
				DeleteDC(memDC);
				DeleteDC(hdcPic);
			   break;
		   case IDC_BUTTON2:
				//MessageBox(hDlg,"Button2 Clicked","info",0);
			   	hdcPic = GetDC(hwndPic);
	            memDC = CreateCompatibleDC(hdcPic);
				/*
				  �Ȱ�ԭ����ͼƬ����
					*/
				 hBrush = CreateSolidBrush(RGB(255,255,255));
                GetClientRect(hwndPic,&rc);
                FillRect(hdcPic,&rc,hBrush);
				//�������ͼƬ
				bitmap2 = LoadBitmap(hinDlg,MAKEINTRESOURCE(IDB_BITMAP2));
			   if(!bitmap2)
			   {
                     MessageBox(hDlg,"Load Bitmap Failed","error",0);
			   }
               GetObject(bitmap2,sizeof(bm),&bm);
                SelectObject(memDC,bitmap2);
                GetClientRect(hwndPic,&rc);
				
				//BitBlt(hdcPic,rc.left,rc.top,rc.right,rc.bottom,memDC,0,0,SRCCOPY);
				StretchBlt(hdcPic,rc.left,rc.top,rc.right-rc.left,rc.bottom-rc.top,memDC,0,0,bm.bmWidth,bm.bmHeight ,SRCCOPY);
                DeleteDC(memDC);
				DeleteDC(hdcPic);
			   break;
			}
		break;
	case WM_LBUTTONDOWN:
          	MessageBox(hDlg,"Mouse Clicked","info",0);
		break;
	case WM_CLOSE:
		EndDialog(hDlg,0);
		break;
	default:
		ret = FALSE;
	}

   return ret;
}