﻿
// Lesson58-create-processDlg.cpp : 实现文件
//

#include "stdafx.h"
#include "Lesson58-create-process.h"
#include "Lesson58-create-processDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CLesson58createprocessDlg 对话框



//对话框构造函数
CLesson58createprocessDlg::CLesson58createprocessDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CLesson58createprocessDlg::IDD, pParent)
	, m_hProc(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CLesson58createprocessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_FILE, m_edit_file);
	DDX_Control(pDX, IDC_END_PROC, m_btnEnd);
}

BEGIN_MESSAGE_MAP(CLesson58createprocessDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_NEW_PROC, &CLesson58createprocessDlg::OnBnClickedBtnNewProc)
	ON_BN_CLICKED(IDC_BTN_CHOICE, &CLesson58createprocessDlg::OnBnClickedBtnChoice)
	ON_BN_CLICKED(IDC_BTN_CREATE, &CLesson58createprocessDlg::OnBnClickedBtnCreate)
	ON_BN_CLICKED(IDC_EXIT, &CLesson58createprocessDlg::OnBnClickedExit)
	ON_BN_CLICKED(IDC_END_PROC, &CLesson58createprocessDlg::OnBnClickedEndProc)
	ON_BN_CLICKED(IDC_BTN_TEST, &CLesson58createprocessDlg::OnBnClickedBtnTest)
END_MESSAGE_MAP()


// CLesson58createprocessDlg 消息处理程序

BOOL CLesson58createprocessDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CLesson58createprocessDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CLesson58createprocessDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CLesson58createprocessDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

BOOL CLesson58createprocessDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
      {
          switch (pMsg->wParam)
         {
         case VK_RETURN: //屏蔽回车键
             return TRUE;
          case VK_ESCAPE: //屏蔽ESC键
             return TRUE;
         
         default:
             break;
         }
     }
     return CDialog::PreTranslateMessage(pMsg);

}

void CLesson58createprocessDlg::OnBnClickedBtnNewProc()
{
	// TODO: 在此添加控件通知处理程序代码
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory(&si,sizeof(si));
	si.cb = sizeof(si);
	ZeroMemory(&pi,sizeof(pi));
	//没有命令行参数
	//if(!CreateProcess(_T("C:\\windows\\system32\\notepad.exe"),
	//	_T("\t hello.txt"),NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
	//{
	//  AfxMessageBox(_T("创建子进程失败！！"));
	//  return;//创建进程失败程序就结束
	//}

	//有命令行参数
	if(!CreateProcess(_T("C:\\windows\\system32\\notepad.exe"),
		_T("\t hello.txt"),NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
	{
	  AfxMessageBox(_T("创建子进程失败！！"));
	  return;//创建进程失败程序就结束
	}


}


void CLesson58createprocessDlg::OnBnClickedBtnChoice()
{
	// TODO: 在此添加控件通知处理程序代码
	CString filePath;
	CFileDialog dlg(TRUE);
	if(IDOK == dlg.DoModal())
	{
		filePath = dlg.GetPathName();
		//MessageBox(filePath);
		//当用户选择了文件的完整路径，才能创建进程
		STARTUPINFO si;
		PROCESS_INFORMATION pi;
		ZeroMemory(&si,sizeof(si));
		si.cb = sizeof(si);
		ZeroMemory(&pi,sizeof(pi));
		if(!CreateProcess(filePath,
			NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
		{
		  AfxMessageBox(_T("创建子进程失败！！"));
		  return;//创建进程失败程序就结束
		}
		SetDlgItemText(IDC_RESULT,filePath);
	}
	else
	{
	   //AfxMessageBox(_T("用户取消了进程创建！！"));
		SetDlgItemText(IDC_RESULT,_T("用户取消了进程创建！！"));
	}
	
}


void CLesson58createprocessDlg::OnBnClickedBtnCreate()
{
	// TODO: 在此添加控件通知处理程序代码
	//HANDLE hfile;
	CString str;
	GetDlgItemText(IDC_EDIT_FILE,str);
	if(str.GetLength()==0)
	{
	  MessageBox(_T("请输入文件路径！"));
	  m_edit_file.SetFocus();
	}

	WIN32_FIND_DATA wfd;
	if(INVALID_HANDLE_VALUE == FindFirstFile(str,&wfd))
	{
	  SetDlgItemText(IDC_FIND_RESULT,_T("找不到文件"));
	}
	else
	{
	   SetDlgItemText(IDC_FIND_RESULT,str);
	   STARTUPINFO si;
		PROCESS_INFORMATION pi;
		ZeroMemory(&si,sizeof(si));
		si.cb = sizeof(si);
		ZeroMemory(&pi,sizeof(pi));
		if(!CreateProcess(str,
			NULL,NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
		{
		  AfxMessageBox(_T("创建子进程失败！！"));
		  return;//创建进程失败程序就结束
		}
		//保存进程句柄到成员变量中方便我们终止进程的执行
		m_hProc = pi.hProcess;
		m_btnEnd.EnableWindow(TRUE);
		SetDlgItemInt(IDC_FIND_RESULT2,pi.dwProcessId);
		SetDlgItemInt(IDC_FIND_RESULT3,GetCurrentProcessId());
	}
}


void CLesson58createprocessDlg::OnBnClickedExit()
{
	// TODO: 在此添加控件通知处理程序代码
	if(IDOK==::MessageBox(this->m_hWnd,_T("退出程序?"),_T("退出确认"),MB_OKCANCEL))
	{
	   //ExitProcess(0); //window退出方法
		PostQuitMessage(0);//window退出方法2
		//exit(0);//c语言的退出方法
	}
}


void CLesson58createprocessDlg::OnBnClickedEndProc()
{
	// TODO: 在此添加控件通知处理程序代码
	TerminateProcess(m_hProc,0);
	m_btnEnd.EnableWindow(FALSE);//终止进程后需要把终止按钮禁用
}					 


void CLesson58createprocessDlg::OnBnClickedBtnTest()
{
	// TODO: 在此添加控件通知处理程序代码
	CString str;
	GetDlgItemText(IDC_EDIT_CMD,str);
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	ZeroMemory(&si,sizeof(si));
	si.cb = sizeof(si);
	ZeroMemory(&pi,sizeof(pi));
	
	if(!CreateProcess(_T("fileutil.exe"),
		str.GetBuffer(),NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
	{
	  AfxMessageBox(_T("创建子进程失败！！"));
	  return;//创建进程失败程序就结束
	}
	//注意：Cstring对象转化为LPTSTR的方法是调用Cstring对象的GetBuffer()方法
}
