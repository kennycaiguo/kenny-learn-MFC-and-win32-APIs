#include<Windows.h>
#include<Psapi.h>
#include<stdio.h>
#pragma comment(lib,"Psapi.lib")

BOOL UpdateProcessPrivilege(HANDLE hProcess,LPCTSTR lpPrivilegeName = SE_DEBUG_NAME);//��������Ȩ�޵ĺ���
void OutputProcessInfo(DWORD pid);

int main()
{
	//��ʾȨ��
	UpdateProcessPrivilege(GetCurrentProcess());


	DWORD processes[1024],cbNeeded,processCount;//processes�������汣����ǽ��̵�id��
	if(!EnumProcesses(processes,sizeof(processes),&cbNeeded))
	{
	  printf("ö�ٽ���ʧ��\n");
	  return 1;
	}
	//����һ���ж��ٸ�����
	processCount = cbNeeded / sizeof(DWORD);
	printf("total process:%d\n",processCount);
	for(DWORD i=0;i<processCount;i++)
	{
	  OutputProcessInfo(processes[i]);
	}

	system("pause");
	return 0;
}

void OutputProcessInfo(DWORD pid)
{
	TCHAR procName[MAX_PATH] = TEXT("<unknown>");
	HMODULE hModule;
	DWORD dwNeeded;
	HANDLE hProcess;
	//����pid��ȡ���̾��
	hProcess = OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ,FALSE,pid);
	if(INVALID_HANDLE_VALUE == hProcess)
	{
		printf("��ȡ������Ϣ����\n");
		return;
	}

	if(EnumProcessModules(hProcess,&hModule,sizeof(hModule),&dwNeeded))//ֻ��ʾ��ȡ����
	{
		GetModuleBaseName(hProcess,hModule,procName,sizeof(procName)/sizeof(TCHAR));
	    printf("%s (pid: %u)\n",procName,pid);
	}
	
	CloseHandle(hProcess);
}

BOOL UpdateProcessPrivilege(HANDLE hProcess,LPCTSTR lpPrivilegeName)
{
	HANDLE hToken;
	int iResult;
	TOKEN_PRIVILEGES tokenPrivileges;

	if(OpenProcessToken(hProcess,TOKEN_ALL_ACCESS,&hToken))
	{
	   LUID destLuid;
	   if(LookupPrivilegeValue(NULL,lpPrivilegeName,&destLuid))
	   {
		   tokenPrivileges.PrivilegeCount =1;
		   tokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		   tokenPrivileges.Privileges[0].Luid = destLuid;
		   if(AdjustTokenPrivileges(hToken,FALSE,&tokenPrivileges,0,NULL,NULL))
		   {
		      return TRUE;
		   }
	   }
	}
	return FALSE;
}