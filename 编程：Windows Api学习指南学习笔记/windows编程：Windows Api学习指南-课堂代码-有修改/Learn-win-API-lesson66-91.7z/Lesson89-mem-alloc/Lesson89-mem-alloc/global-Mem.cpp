#include"stdafx.h"
#include <Windows.h>
#include <tchar.h>

void _cdecl main()
{
    //PSECURITY_DESCRIPTOR pSD;
	LPTSTR lpstr;

    //pSD = (PSECURITY_DESCRIPTOR) GlobalAlloc(
    //       GMEM_FIXED,
    //       sizeof(PSECURITY_DESCRIPTOR));

    //// Handle error condition
    //if( pSD == NULL )
    //{
    //   _tprintf(TEXT("GlobalAlloc failed (%d)\n"), GetLastError());
    //   return;
    //}

    ////see how much memory was allocated
    //_tprintf(TEXT("GlobalAlloc allocated %d bytes\n"), GlobalSize(pSD));

    //// Use the memory allocated

    //// Free the memory when finished with it
    //GlobalFree(pSD);

	lpstr = (LPTSTR)GlobalAlloc(
           GMEM_FIXED,
           1024);
	if( lpstr == NULL )
    {
       _tprintf(TEXT("GlobalAlloc failed (%d)\n"), GetLastError());
       return;
    }
	/*lstrcpy(lpstr,_T("Hello,Memory"));*/
	 memset(lpstr,0,1024);
	 CopyMemory(lpstr,_T("Hello,Memory"),12*sizeof(TCHAR));
	 //_tprintf(TEXT("�ڴ��е�����:%s\n"),lpstr);//û����ʾ
	 MessageBox(NULL,lpstr,lpstr,0);//ok,����ʾ:Hello,Memory��Ϣ��
	 _tprintf(TEXT("GlobalAlloc allocated %d bytes\n"), GlobalSize(lpstr));
	 GlobalFree(lpstr);

}
