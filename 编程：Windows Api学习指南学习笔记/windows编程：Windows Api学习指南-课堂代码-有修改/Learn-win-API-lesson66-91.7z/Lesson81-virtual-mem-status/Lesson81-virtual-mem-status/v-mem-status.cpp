#include<Windows.h>
#include<Psapi.h>
#include<strsafe.h>
#include"resource.h"
#pragma comment(lib,"Psapi.lib")

//����timer ��ID
#define TIMER_ID 1
int factor = 1024*1024*1024;

void DisplayMemInfo(HWND hdlg,char* szBuf,int len)
{
	    MEMORYSTATUSEX mse;
	    PROCESS_MEMORY_COUNTERS_EX pmce;
	    memset(szBuf,0,64);
		mse.dwLength = sizeof(mse);//һ��Ҫ��ʼ������

		GlobalMemoryStatusEx(&mse);
		StringCchPrintf(szBuf,len,"%d %s",mse.dwMemoryLoad,"%");
		SetDlgItemText(hdlg,IDC_EDIT_LOAD,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%d GB",mse.ullTotalPhys/factor);
		SetDlgItemText(hdlg,IDC_EDIT_TOTAL_PHIS,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)mse.ullAvailPhys/1024);
		SetDlgItemText(hdlg,IDC_EDIT_MEM_AVAIL,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%d GB",(__int64)mse.ullTotalPageFile/factor);
		SetDlgItemText(hdlg,IDC_EDIT_TOT_PAGE,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)mse.ullAvailPageFile/1024);
		SetDlgItemText(hdlg,IDC_EDIT_AVAI_PAGE,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)mse.ullTotalVirtual/1024);
		SetDlgItemText(hdlg,IDC_EDIT_TOT_V,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)mse.ullAvailVirtual/1024);
		SetDlgItemText(hdlg,IDC_EDIT_MEM_V_AVAIL,szBuf);

		//��ȡWorkingSet��PrivateBytes
		GetProcessMemoryInfo(GetCurrentProcess(),(PROCESS_MEMORY_COUNTERS*)&pmce,sizeof(pmce));
		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)pmce.WorkingSetSize/1024);
		SetDlgItemText(hdlg,IDC_EDIT_WKSET,szBuf);

		memset(szBuf,0,64);
		StringCchPrintf(szBuf,len,"%I64d KB",(__int64)pmce.PrivateUsage/1024);
		SetDlgItemText(hdlg,IDC_EDIT_PRIVATE_BYTE,szBuf);
}

INT_PTR CALLBACK DlgProc(HWND,UINT,WPARAM,LPARAM);


int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE prev,LPTSTR lpCmd, int nshow)
{
	DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc);
	return 0;
}

INT_PTR CALLBACK DlgProc(HWND hdlg,UINT msg,WPARAM wParam,LPARAM lParam)
{
	//��������
	char szBuf[64];
	BOOL ret = TRUE;

	switch(msg)
	{
	case WM_CLOSE:
		EndDialog(hdlg,FALSE);
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			if(IDOK == MessageBox(hdlg,TEXT("�˳�����"),TEXT("ȷ��"),MB_OKCANCEL))
			{
				EndDialog(hdlg,FALSE);
			}
			break;
		}
		break;
	case WM_INITDIALOG:
		//���ö�ʱ��
		//DisplayMemInfo(hdlg,szBuf,_countof(szBuf));//�ȵ������������ʾһ����Ϣ,����һ��ʼʲô��û����ʾ
		SetTimer(hdlg,TIMER_ID,1000,NULL);//���ö�ʱ��
		SendMessage(hdlg,WM_TIMER,TIMER_ID,0);
		break;
	case WM_TIMER:
		DisplayMemInfo(hdlg,szBuf,_countof(szBuf));
		break;
	default:
		ret =FALSE;
	}

	return ret;
}