#include<Windows.h>
#include<stdio.h>
#include<tchar.h>
#include<strsafe.h> //���ͷ�ļ���Ҫ��tchar.h����д,���򱣴�
#include"resource.h"


PTSTR BigNumToStr(long lNum,LPSTR szBuf,DWORD bufSize);
INT_PTR CALLBACK DlgProc(HWND hdlg,UINT msg,WPARAM wParam ,LPARAM lParam);
void ShowCpuTypeInfo(HWND hdlg,WORD wArch,WORD wLevel,WORD wRevi);

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE prev,LPTSTR lpCmd,int nShow)
{
  DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,DlgProc);
  return 0;
}

INT_PTR CALLBACK DlgProc(HWND hdlg,UINT msg,WPARAM wParam ,LPARAM lParam)
{
	BOOL ret = TRUE;
	switch(msg)
	{
	case WM_INITDIALOG:
		//MessageBox(hdlg,TEXT("hello"),TEXT("TEST"),0);
		//��ȡ�ڴ���Ϣ�������õ��༭������
		SYSTEM_INFO sinf;
		GetNativeSystemInfo(&sinf);//64λϵͳ��Ҫʹ���������
		
		TCHAR szmask[256];//
		//Ϊ�˸��õ���ʾ��Ϣ���ǰ�����ת��Ϊ�ַ����������õ�����ʾ��ʽ,ע����������ʹ��΢���Ƽ��İ�ȫ�ַ�������
		//StringCchPrintfȡ����sprinft,wsprintf,swprintf,stprintf,wnsprintf,snprintf�ȴ�����
		/*SetDlgItemText(hdlg,IDC_EDIT_ARCH,BigNumToStr(sinf.wProcessorArchitecture,szarch,_countof(szarch)));
		SetDlgItemText(hdlg,IDC_EDIT_LEVEL,BigNumToStr(sinf.wProcessorLevel,szlevel,_countof(szlevel)));
	
		SetDlgItemText(hdlg,IDC_EDIT_REVI,BigNumToStr(sinf.wProcessorRevision,szrevi,_countof(szrevi)));*/
		StringCchPrintf(szmask,_countof(szmask),TEXT("0x%016I64X"),(__int64)sinf.dwActiveProcessorMask);//������16��������ʾ
		SetDlgItemText(hdlg,IDC_EDIT_MASK,szmask);
		SetDlgItemInt(hdlg,IDC_EDIT_CPU_NUM,sinf.dwNumberOfProcessors,TRUE);
		//��ʾcpu�ͺ���Ϣ���Զ��庯��
		ShowCpuTypeInfo(hdlg,sinf.wProcessorArchitecture,sinf.wProcessorLevel,sinf.wProcessorRevision);
		break;
	case WM_CLOSE:
		EndDialog(hdlg,FALSE);
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			if(IDOK==MessageBox(hdlg,TEXT("�˳�����"),TEXT("ȷ��"),MB_OKCANCEL))
			{
				EndDialog(hdlg,FALSE);
			}
			break;
		}
		break;
	default:
		ret = FALSE;//������Ҫ����λFALSE��Ĭ�϶Ի�����̴������ǲ�����Ȥ����Ϣ
		break;
	}
	return ret;
}

//ʹ��������ʾ��ʽλ1,000,000.00�ĸ�ʽ
PTSTR BigNumToStr(long lNum,LPSTR szBuf,DWORD bufSize)
{
   TCHAR szNum[100];
   StringCchPrintf(szNum,sizeof(szNum),TEXT("%d"),lNum);
   NUMBERFMT nf;//���ָ�ʽ�ṹ��,ʹ��ǰ��Ҫ��ʼ��
   nf.NumDigits = 0;
   nf.LeadingZero = FALSE;
   nf.Grouping =3;
   nf.lpDecimalSep = TEXT(".");//����С����ָ��
   nf.lpThousandSep = TEXT(",");//����ǧ��λ�ָ���
   nf.NegativeOrder = 0;
   GetNumberFormat(LOCALE_USER_DEFAULT,0,szNum,&nf,szBuf,bufSize);//���ø�ʽΪ1,000,000.00

   return szBuf;
}

//��ʾCPU�ͺ���Ϣ���Զ��庯��
void ShowCpuTypeInfo(HWND hdlg,WORD wArch,WORD wLevel,WORD wRevi)
{
   TCHAR szarch[64]  = TEXT("unknown");//processor architecture
   TCHAR szlevel[64] = TEXT("unknown");//processor level
   TCHAR szrevi[64]  = TEXT("unknown");//processor revision
   //������Ϣ
   switch(wArch)
   {
   case PROCESSOR_ARCHITECTURE_INTEL:
	   _tcscpy_s(szarch,_countof(szarch),TEXT("Intel"));//tchar.h
	   switch(wLevel)
	   {
	   case 3:
	   case 4:
		   StringCchPrintf(szlevel,_countof(szlevel),TEXT("80%c86"),wLevel+'0');
		   StringCchPrintf(szrevi,_countof(szrevi),TEXT("%c%d"),HIBYTE(wRevi)+TEXT('A'),LOBYTE(wRevi));
			 break;
	   case 5:
		   _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium"));
		   StringCchPrintf(szrevi,_countof(szrevi),TEXT("Model %d Stepping %d"),HIBYTE(wRevi),LOBYTE(wRevi));
			 break;
	   case 6:
		   switch(HIBYTE(wRevi))
		   {
		   case 1:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium pro"));
			break;
		   case 3:
           case 5:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium II"));
			break;
		   case 6:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Celeron"));
			break;
		   case 7:
		   case 8:
           case 11:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium III"));
			break;
		   case 9:
           case 13:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium M"));
			break;
			case 10:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Pentium Xeon"));
			break;
			case 15:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Core 2 Duo"));
			break;
			default:
            _tcscpy_s(szlevel,_countof(szlevel),TEXT("Core 2 Duo"));
			break;
		   }
		    StringCchPrintf(szrevi,_countof(szrevi),TEXT("Model %d Stepping %d"),HIBYTE(wRevi),LOBYTE(wRevi));
		break;
	   case 15:
		   _tcscpy_s(szlevel,_countof(szlevel),TEXT("Unknown Pentium"));
		   StringCchPrintf(szrevi,_countof(szrevi),TEXT("Model %d Stepping %d"),HIBYTE(wRevi),LOBYTE(wRevi));
			 break;
	   }
	   break;
   case PROCESSOR_ARCHITECTURE_AMD64:
	    _tcscpy_s(szarch,_countof(szarch),TEXT("AMD64"));
		StringCchPrintf(szlevel,_countof(szlevel),TEXT("%d"),wLevel);
	    StringCchPrintf(szrevi,_countof(szrevi),TEXT("Model %d Stepping %d"),HIBYTE(wRevi)+TEXT('A'),LOBYTE(wRevi));
	   break;
   case PROCESSOR_ARCHITECTURE_IA64:
	   _tcscpy_s(szarch,_countof(szarch),TEXT("IA64"));
	   StringCchPrintf(szlevel,_countof(szlevel),TEXT("%d"),wLevel);
	   StringCchPrintf(szrevi,_countof(szrevi),TEXT("Model %d Stepping %d"),HIBYTE(wRevi)+TEXT('A'),LOBYTE(wRevi));
	   break;
   case PROCESSOR_ARCHITECTURE_UNKNOWN:
   default:
	   _tcscpy_s(szarch,_countof(szarch),TEXT("δ֪�ͺ�CPU"));
	   break;
   }

   
   //�����Ϣ
   SetDlgItemText(hdlg,IDC_EDIT_ARCH,szarch);
   SetDlgItemText(hdlg,IDC_EDIT_LEVEL,szlevel);
   SetDlgItemText(hdlg,IDC_EDIT_REVI,szrevi);
}