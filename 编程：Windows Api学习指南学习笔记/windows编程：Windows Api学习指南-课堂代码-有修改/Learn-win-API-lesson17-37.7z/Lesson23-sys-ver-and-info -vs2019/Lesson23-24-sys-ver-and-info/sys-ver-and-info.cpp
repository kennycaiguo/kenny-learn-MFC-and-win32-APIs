#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

void ShowVersionInfo()
{
	OSVERSIONINFO osinfo;
	//��2������ṹ����Ҫ��ʼ������һ����С��Ա
	osinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx(&osinfo))//ע�⣬��1�����ex����ʹ�õı�ʾex�ṹ�壡����
	{
		printf("Get OS Version Failed:%d\n",GetLastError());
		return;
	}
	printf("OS Build Number:%d\n",osinfo.dwBuildNumber);
	printf("OS Major Version:%d\n",osinfo.dwMajorVersion);
	printf("OS Minor Version:%d\n",osinfo.dwMinorVersion);
	printf("OS Platform ID:%d\n",osinfo.dwPlatformId);
	printf("Service Pack:%s\n",osinfo.szCSDVersion);

}

void ShowVersionInfoString()
{
	TCHAR szVersionInfo[1024];
	OSVERSIONINFO osinfo;
    *szVersionInfo = NULL;
	//��2������ṹ����Ҫ��ʼ������һ����С��Ա
	osinfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx(&osinfo))//ע�⣬��1�����ex����ʹ�õı�ʾex�ṹ�壡����
	{
		printf("Get OS Version Failed:%d\n",GetLastError());
		return;
	}
	if(osinfo.dwMajorVersion == 5)
	{
		if(osinfo.dwMinorVersion == 0) lstrcat(szVersionInfo,TEXT("Window 2000"));
		else if(osinfo.dwMinorVersion == 1) lstrcat(szVersionInfo,TEXT("Window xp"));
		else if(osinfo.dwMinorVersion == 2) lstrcat(szVersionInfo,TEXT("Window Server 2003"));
	}
	else if(osinfo.dwMajorVersion == 6)
	{
		if(osinfo.dwMinorVersion == 0) lstrcat(szVersionInfo,TEXT("Window Vista"));
	    else if(osinfo.dwMinorVersion == 1) lstrcat(szVersionInfo,TEXT("Window7"));
		else if(osinfo.dwMinorVersion == 2) lstrcat(szVersionInfo,TEXT("Window8"));
		else if(osinfo.dwMinorVersion == 3) lstrcat(szVersionInfo,TEXT("Window8.1"));
	   
	}
	else if(osinfo.dwMajorVersion == 10)
	{
		lstrcat(szVersionInfo,TEXT("Window10"));
	}

	printf("��ǰ����ϵͳ��:%s\n",szVersionInfo);
	printf("Windows %d.%d Build %d\n",osinfo.dwMajorVersion,
		osinfo.dwMinorVersion,osinfo.dwBuildNumber);
	
}

void ShowSystemInfo()
{
	SYSTEM_INFO sysinfo;
	GetSystemInfo(&sysinfo);
	printf("OEM ID:%d\n",sysinfo.dwOemId);
	printf("Number Of Processors:%d\n",sysinfo.dwNumberOfProcessors);
	printf("Page Size:%d\n",sysinfo.dwPageSize);
	printf("Processor Type:%d\n",sysinfo.dwProcessorType);
	printf("Maximum Application Address:%d\n",sysinfo.lpMaximumApplicationAddress);
	printf("Minimum Application Address:%d\n",sysinfo.lpMinimumApplicationAddress);
	printf("Processor Architecture:%d\n",sysinfo.wProcessorArchitecture);
	printf("Processor Level:%d\n",sysinfo.wProcessorLevel);
	printf("Processor Revision:%d\n",sysinfo.wProcessorRevision);

}


int main()
{
	//ShowVersionInfo();
	//ShowVersionInfoString();
	ShowSystemInfo();
	system("pause");
	return 0;
}