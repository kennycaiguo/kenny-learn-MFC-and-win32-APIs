#include<Windows.h>

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE prev,LPTSTR cmdline,int nshow)
{
	HDC hdc = GetDC(NULL);
	HPEN pen,penOld;
	HBRUSH brush,brushOld;
	pen = CreatePen(PS_SOLID,2,RGB(255,0,255));
	brush = CreateSolidBrush(RGB(0,255,255));
	penOld = (HPEN)SelectObject(hdc,pen);
	brushOld = (HBRUSH)SelectObject(hdc,brush);
	LineTo(hdc,500,500);
	Rectangle(hdc,200,200,500,500);
	SelectObject(hdc,penOld);
	DeleteObject(pen);
	SelectObject(hdc,brush);
	DeleteObject(brush);
	ReleaseDC(NULL,hdc);

	return 0;
}