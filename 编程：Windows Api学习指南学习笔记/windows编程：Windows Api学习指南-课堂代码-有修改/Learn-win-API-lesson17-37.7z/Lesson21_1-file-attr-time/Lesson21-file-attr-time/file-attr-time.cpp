#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

DWORD DisplayFileTime(LPFILETIME lpfileTime)
{
	FILETIME localFileTime;
	SYSTEMTIME sysTime;
	if(!FileTimeToLocalFileTime(lpfileTime,&localFileTime))
	{
	   printf("Convert File Time To Local Time Failed: %d\n",GetLastError());
	   return 1;
	}
	if(!FileTimeToSystemTime(&localFileTime,&sysTime))
	{
	   printf("Convert File Time To System Time Failed: %d\n",GetLastError());
	   return 1;
	}
	printf("%d��%#02d��%#02d�� %#02d:%#02d:%#02d\n",sysTime.wYear,sysTime.wMonth,sysTime.wDay,sysTime.wHour,sysTime.wMinute,sysTime.wSecond);

	return 0;
}

DWORD ShowFileSize(LPWIN32_FILE_ATTRIBUTE_DATA lpw32fad)
{
	ULONGLONG lgSize;//64δ
	DWORD hiSize,lwSize;
	hiSize = lpw32fad->nFileSizeHigh;//
	lwSize = lpw32fad->nFileSizeLow;
	lgSize = hiSize;//�Ƚ��ո��ֶε�����
	lgSize <<= 32;//Ȼ������32λ��Ҳ�����ƶ�����32λ
	lgSize += lwSize; //�ѵ��ֶε�ֵ���ӽ���

	printf("%I64u bytes\n",lgSize);
	return 0;
}
DWORD ShowFileAttributs(LPTSTR szPath)
{
	WIN32_FILE_ATTRIBUTE_DATA w32fad;
	
	if(!GetFileAttributesEx(szPath,GetFileExInfoStandard,&w32fad))
	{
	  printf("Get File Attributes Failed: %x\n",GetLastError());
	  return 1;
	}
	else
	{   printf("========File Report Of %s======== \n",szPath);
	
		//printf("%d\n",w32fad.dwFileAttributes);
	   
		printf("Creation Time: ");
		DisplayFileTime(&w32fad.ftCreationTime);
		printf("Access Time: ");
		DisplayFileTime(&w32fad.ftLastAccessTime);
		printf("Last Modify Time: ");
		DisplayFileTime(&w32fad.ftLastWriteTime);
		printf("File Size: ");
		ShowFileSize(&w32fad);

		//д��1
      if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_NORMAL) 
	  {
		  printf("%s is a normal file\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_READONLY)
	  {
	     printf("%s is a readonly file\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN)
	  {
	     printf("%s is a hidden file\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_ARCHIVE)
	  {
	     printf("%s has been Archived...\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_COMPRESSED)
	  {
	     printf("%s has been Compressed...\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_ENCRYPTED)
	  {
	     printf("%s has been Encrypted...\n",szPath);
	  }
	  else if(w32fad.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	  {
	     printf("%s is a directory\n",szPath);
	  }

      
	}
	
   return 0;
}


int main()
{
	ShowFileAttributs(TEXT("Debug"));
	//ShowFileAttributs(TEXT("test.txt"));
	system("pause");
	return 0;
}