#include<Windows.h>
#include"resource.h"



void DrawGraph(HWND hwnd,int shape,COLORREF color)
{
	HDC hdc;
	HBRUSH hBGBrush,hbrush,hOldBrush;
	RECT rc;
	GetClientRect(hwnd,&rc);
	hbrush =  CreateSolidBrush(color);
	hBGBrush = CreateSolidBrush(RGB(255,255,255));
	hdc = GetDC(hwnd);
	//1.����ɫ����
	FillRect(hdc,&rc,hBGBrush);
	hOldBrush = (HBRUSH)SelectObject(hdc,hbrush);
	//��ͼ
	if(shape){
		Rectangle(hdc,rc.left,rc.top,rc.right,rc.bottom);
	}
	else
	{
       Ellipse(hdc,rc.left,rc.top,rc.right,rc.bottom);
	}
	DeleteObject(SelectObject(hdc,hOldBrush));
	ReleaseDC(hwnd,hdc);

}

INT_PTR CALLBACK DlgProc(HWND hDlg,UINT uMsg,WPARAM wParam,LPARAM lParam)
{
	int cmdId;
	BOOL ret = TRUE;
	static COLORREF color;
    static int shape;
	static HWND hwndPaint;//��ͼ���ھ��
	
	switch(uMsg)
	{
	case WM_INITDIALOG:
		hwndPaint = GetDlgItem(hDlg,IDC_STATIC_DRAW);//��ȡ��ͼ����
		shape = 1;
		color = RGB(255,255,0);
		SendMessage(GetDlgItem(hDlg,IDC_RADIO_YELLOW),BM_SETCHECK,1,0);//����Ĭ��ѡ�л�ɫ
		//SendMessage(GetDlgItem(hDlg,IDC_RADIO_RECT),BM_SETCHECK,1,0);//����Ĭ��ѡ�о���
		SendDlgItemMessage(hDlg,IDC_RADIO_RECT,BM_SETCHECK,1,0);//Ҳ������ôд
		break;
	case WM_PAINT:
		UpdateWindow(hDlg);
		DrawGraph(hwndPaint,shape,color);
	    ret = FALSE;//�ڶԻ����WM_PAINT��Ϣ��Ӧ��Ҫ������һ�䣬����������
		break;
	case WM_COMMAND:
		cmdId = LOWORD(wParam);
		switch(cmdId)
		{
		case IDOK:
			if(IDOK==MessageBox(hDlg,TEXT("�˳�����"),TEXT("�˳�ȷ��"),MB_OKCANCEL))
			{
			   EndDialog(hDlg,FALSE);
			}
			break;
		case IDC_RADIO_BLACK:
			color = RGB(0,0,0);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_BLUE:
			color = RGB(0,0,255);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_GREEN:
			color = RGB(0,255,0);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_CYAN:
			color = RGB(0,255,255);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_RED:
			color = RGB(255,0,0);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_MAGENTA:
			color = RGB(255,0,255);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_YELLOW:
			color = RGB(255,255,0);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_WHITE:
			color = RGB(255,255,255);
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_RECT:
			shape = 1;
			DrawGraph(hwndPaint,shape,color);
			break;
		case IDC_RADIO_ELLIPSE:
			shape =0;
			DrawGraph(hwndPaint,shape,color);
			break;
		default:
			ret = FALSE;
			break;
		}
		break;
	case WM_CLOSE:
		EndDialog(hDlg,FALSE);
		break;
	default:
		ret = FALSE;
		break;
	}
	return ret;
}

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrev,LPTSTR lpCmd,int nShow)
{

    DialogBox(hInstance,MAKEINTRESOURCE(IDD_DLGMAIN),NULL,DlgProc);
	return 0;
}