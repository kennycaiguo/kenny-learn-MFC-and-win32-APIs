
// Lesson18-dir-opDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"


// CLesson18diropDlg �Ի���
class CLesson18diropDlg : public CDialogEx
{
// ����
public:
	CLesson18diropDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_LESSON18DIROP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedBtnCreate();
	CEdit m_editNewDir;
	afx_msg void OnBnClickedBtnGet();
	afx_msg void OnBnClickedBtnSet();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedModule();
	afx_msg void OnBnClickedModule2();
	afx_msg void OnClose();
};
