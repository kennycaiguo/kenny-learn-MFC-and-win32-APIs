#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

int main()
{
	BOOL fResult;
	int mouseInfo[3];
	fResult = SystemParametersInfo(SPI_GETMOUSE,0,&mouseInfo,0);
	if(!fResult)
	{
	   printf("Get Mouse Info Failed:%d\n",GetLastError());
	   return 1;
	}
	printf("first element:%d\n",mouseInfo[0]); //6
	printf("second element:%d\n",mouseInfo[1]);//10
	printf("third element:%d\n",mouseInfo[2]);//1,�����ָ����ƶ��ٶ�
	system("pause");
	return 0;
}