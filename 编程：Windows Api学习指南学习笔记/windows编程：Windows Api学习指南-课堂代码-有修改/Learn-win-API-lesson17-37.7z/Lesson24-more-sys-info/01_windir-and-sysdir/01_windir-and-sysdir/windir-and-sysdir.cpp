#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

int main()
{
	DWORD dwPcNameLength = MAX_COMPUTERNAME_LENGTH+1;
	TCHAR szSysDir[MAX_PATH],szWinDir[MAX_PATH],szPCName[MAX_COMPUTERNAME_LENGTH+1];
	DWORD dwUserNameLength = 64;
	TCHAR szUserName[64];

	GetSystemDirectory(szSysDir,MAX_PATH);
	GetWindowsDirectory(szWinDir,MAX_PATH);
	GetComputerName(szPCName,&dwPcNameLength);//�����пӣ���Ҫע��
	GetUserName(szUserName,&dwUserNameLength);

	printf("ϵͳĿ¼��%s\n",szSysDir);
	printf("WindowsĿ¼��%s\n",szWinDir);
	printf("�������ƣ�%s\n",szPCName);
	printf("��ǰ�û�����%s\n",szUserName);

	system("pause");
	return 0;
}
