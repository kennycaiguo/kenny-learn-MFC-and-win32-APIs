#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>


int main(int argc,char* argv[])
{

	if(argc < 3)
	{
	  printf("Usage: copy_w2 file1 file2\n");
	  return -1;
	}
	if(!CopyFile(argv[1],argv[2],TRUE))
	{
	   printf("File %s already exists,over write(y/n)?: ",argv[1]);
	   if('y' == getchar())
	   {
	     if(!CopyFile(argv[1],argv[2],FALSE))
		 {
			 printf("Copy Error: %x\n",GetLastError());
			 return 1;
		 }
		 else
		 {
		      printf("Copy Finished Successfully...");
		 }
	   }
	}
	else
	{
	    printf("Copy Finished Successfully...");
	}

	return 0;

}
