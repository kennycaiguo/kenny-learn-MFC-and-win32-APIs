#include<Windows.h>
#include<stdio.h>
#include<stdlib.h>

#define BUF_SIZE 256

int main(int argc,char* argv[])
{
	HANDLE hIn,hOut;
	char szRead[BUF_SIZE];
	DWORD dIn,dOut;
	if(argc < 3)
	{
	  printf("Usage: copy_w1 file1 file2\n"); 
	  return -1;
	}
	hIn = CreateFile(argv[1],GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE == hIn)
	{
	   printf("Open file error:%x\n",GetLastError());
	   return 1;
	}
	hOut = CreateFile(argv[2],GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
	if(INVALID_HANDLE_VALUE == hOut)
	{
	   printf("Create file error:%x\n",GetLastError());
	   return 2;
	}
	while(ReadFile(hIn,szRead,BUF_SIZE,&dIn,NULL) && dIn >0)
	{
	   WriteFile(hOut,szRead,dIn,&dOut,NULL);
	   if(dOut != dIn)
	   {
		   printf("Fatal Error:%x\n",GetLastError());
		   return 3;
	   }
	}
	printf("Copy File Successfully...\n");
	CloseHandle(hIn);
	CloseHandle(hOut);
	system("pause");
	return 0;
}