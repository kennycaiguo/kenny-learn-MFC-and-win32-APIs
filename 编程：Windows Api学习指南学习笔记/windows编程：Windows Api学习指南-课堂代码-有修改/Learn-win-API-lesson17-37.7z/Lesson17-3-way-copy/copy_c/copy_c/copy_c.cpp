#include<stdio.h>
#include<errno.h>
#include<stdlib.h>

#define BUF_SIZE 256

int main(int argc,char* argv[])
{
	FILE *fIn,*fOut;
	char szRead[BUF_SIZE];
	size_t nIn,nOut;
	
	if(argc < 3)
	{
	   printf("Usage: copy_c file1 file2\n");
	   return -1;
	}

	fIn = fopen(argv[1],"rb");
	if(fIn ==NULL)
	{
		printf("open source file failed\n");
		return 1;
	}

	fOut = fopen(argv[2],"wb");
	if(fOut ==NULL)
	{
		printf("create file failed\n");
		return 2;
	}
	while((nIn = fread(szRead,1,256,fIn)) && nIn > 0)
	{
	    nOut = fwrite(szRead,1,nIn,fOut);
		if(nOut != nIn)
		{
			printf("Fatal Error!!\n");
			return 3;
		}
	}
	fclose(fIn);
	fclose(fOut);
	printf("Copy success....\n");
	system("pause");
	return 0;
}