#include<Windows.h>
#include"resource.h"

HWND hwndBtn,hwndChk,hwndRadio;

void ToggleShowWin(HWND hwnd)
{
	if(IsWindowVisible(hwnd))
	{
		ShowWindow(hwnd,SW_HIDE);
	}
	else
	{
		ShowWindow(hwnd,SW_SHOW);
	}
}

void ToggleEnableCtrl(HWND hwnd)
{
	if(IsWindowEnabled(hwnd))
	{
		EnableWindow(hwnd,FALSE);
	} 
	else
	{
		EnableWindow(hwnd,TRUE);
	}
}
INT_PTR CALLBACK Dlgproc(
  HWND hDlg,
  UINT uMsg,
  WPARAM wParam,
  LPARAM lParam
)
{
	static TCHAR szCaption[128];
	BOOL ret = TRUE;
	int cmdId;
	hwndBtn = GetDlgItem(hDlg,IDC_BUTTON1);
	hwndChk = GetDlgItem(hDlg,IDC_CHECK1);
	hwndRadio = GetDlgItem(hDlg,IDC_RADIO1);
	LRESULT lCheck;
	switch(uMsg)
	{
	case WM_COMMAND:
		cmdId = LOWORD(wParam);
		switch(cmdId)
		{
		case IDOK://��ֹ�û����س��˳�����
			if(IDOK == MessageBox(hDlg,TEXT("Exit App?"),TEXT("Info"),MB_OKCANCEL))
			{
			   EndDialog(hDlg,FALSE);
			}
			break;
		case IDC_BUTTON1:
			MessageBox(hDlg,TEXT("Button Clicked"),TEXT("Info"),MB_OK);
			break;
		case IDC_CHECK1:
			MessageBox(hDlg,TEXT("CheckBox Clicked"),TEXT("Info"),MB_OK);
			break;
		case IDC_RADIO1:
			MessageBox(hDlg,TEXT("RadioButton Clicked"),TEXT("Info"),MB_OK);
			break;
		case IDC_BTN_SET:
			SetWindowText(hwndBtn,"Setted...");
			break;
		case IDC_BTN_GETTEXT:
			GetWindowText(hwndBtn,szCaption,128);
			MessageBox(hDlg,szCaption,TEXT("Info"),MB_OK);
			break;
		case IDC_BTN_SHOW_HIDE:
			/*ToggleShowWin(hwndBtn);
			ToggleShowWin(hwndChk);
			ToggleShowWin(hwndRadio);*/
			ShowWindow(hwndBtn,!IsWindowVisible(hwndBtn));//���õ�д��������Ҫ�Լ����庯��
			ShowWindow(hwndChk,!IsWindowVisible(hwndChk));
			ShowWindow(hwndRadio,!IsWindowVisible(hwndRadio));
            break;
		case IDC_EN_DISABLE:
			//ToggleEnableCtrl(hwndBtn);
			//ToggleEnableCtrl(hwndChk);
			//ToggleEnableCtrl(hwndRadio);
			EnableWindow(hwndBtn,!IsWindowEnabled(hwndBtn));//���õ�д��������Ҫ�Լ����庯��
			EnableWindow(hwndChk,!IsWindowEnabled(hwndChk));
			EnableWindow(hwndRadio,!IsWindowEnabled(hwndRadio));
			break;
		case IDC_BTN_CHECK:
			SendMessage(hwndChk,BM_SETCHECK,BST_CHECKED,0);//�����wParam����BST_CHECKED��Ҳ����1
			SendMessage(hwndRadio,BM_SETCHECK,BST_CHECKED,0);
			break;
		case IDC_BTN_UNCHECK:
			SendMessage(hwndChk,BM_SETCHECK,BST_UNCHECKED,0);//�����wParam����BST_UNCHECKED��Ҳ����0
			SendMessage(hwndRadio,BM_SETCHECK,BST_UNCHECKED,0);
			break;
		case IDC_BTN_GETSTATE:
			lCheck = SendMessage(hwndChk,BM_GETCHECK,0,0);//��ȡѡ��״̬��Ҫ����SendMessage�����ķ���ֵ
			if(lCheck)
			{
				MessageBox(hDlg,TEXT("Checked"),TEXT("Info"),MB_OK);
			}
			else
			{
				MessageBox(hDlg,TEXT("UnChecked"),TEXT("Info"),MB_OK);
			}
			break;
		}
		break;
	case WM_CLOSE: //�û����x��ťֱ���˳�����
		EndDialog(hDlg,FALSE);
	default:
		ret = FALSE;
		break;
	}

	return ret;
}

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE prec,LPTSTR lpCmdLine,int nCmdShow)
{
   DialogBox(hInstance,MAKEINTRESOURCE(IDD_DIALOG1),NULL,Dlgproc);
   return 0;
}